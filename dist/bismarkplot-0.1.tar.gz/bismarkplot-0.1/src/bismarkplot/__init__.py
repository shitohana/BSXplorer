from BismarkFiles import BismarkFiles, Bismark, BarPlot, BoxPlot, LinePlot, HeatMap
from read_bismark import read_bismark_batches
from read_genome import read_genome