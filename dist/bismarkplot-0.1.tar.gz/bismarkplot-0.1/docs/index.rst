Welcome to BismarkPlot's documentation!
=======================================
This page gives an overview of all public objects, functions and methods.

.. toctree::

.. autosummary::
   :toctree: _autosummary

    Bismark
    BismarkFiles
    read_bismark
    read_genome
    LinePlot
    HeatMap
    BoxPlot
    BarPlot