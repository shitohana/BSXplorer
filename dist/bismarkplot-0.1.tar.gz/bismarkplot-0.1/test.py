from bismarkplot import read_genome
from bismarkplot import BismarkFiles

genome = read_genome(
    file = '/home/kistain/Documents/BSSEQ/flax_NCBI_gene_v2.0_202008.gff3',
    flank_length=2000
)

files = [
        f'/home/kistain/Documents/BSSEQ/MAt{name}_pe.deduplicated.CX_report.txt' for name in [
            'F3-1', 'F3-2'#, 'F3-3', 'K3-1', 'K3-2', 'K3-3'
    ]
]

data = BismarkFiles(
    files = files,
    genome=genome,
    flank_windows=500,
    gene_windows=2000,
    line_plot=True,
    heat_map=True,
    bar_plot=True,
    box_plot=True
)

labels = ['F3-1', 'F3-2', 'F3-3', 'K3-1', 'K3-2', 'K3-3']

data.draw_line_plots_all(labels=labels, out_dir='test')
data.draw_heat_maps_all(labels=labels, out_dir='test')
data.draw_bar_plot(labels=labels, out_dir='test')
data.draw_box_plot(labels=labels, out_dir='test')

print(1)